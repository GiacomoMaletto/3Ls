function love.conf(t)
    t.console = true
    t.window.fullscreen = true
end
